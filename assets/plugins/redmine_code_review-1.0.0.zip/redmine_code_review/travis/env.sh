export TRAVISDIR=`pwd`
export PATH_TO_PLUGIN=`dirname ${TRAVISDIR}`
export TESTSPACE=$PATH_TO_PLUGIN/testspace
export PATH_TO_REDMINE=$TESTSPACE/redmine
export RAILS_ENV=test